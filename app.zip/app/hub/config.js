// Firebase do Hub. PRODUÇÃO = mesmo projeto do EPI Manager (o hub só LÊ estoque e preços).
// Para testar com o projeto uniluvas-teste, troque pelos valores dele
// (Firebase > Configurações do projeto > Seus apps > Configuração do SDK).
var firebaseConfig={
  apiKey:"AIzaSyCQbP8V9oUDH-WfjhHZrZ0Zpxwpxv8TpS8",
  authDomain:"epi-parauapebas.firebaseapp.com",
  databaseURL:"https://epi-parauapebas-default-rtdb.firebaseio.com",
  projectId:"epi-parauapebas",
  messagingSenderId:"1046950789657",
  appId:"1:1046950789657:web:e4d51d940d2d857b3fa088"
};
