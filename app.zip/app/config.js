// Configurações compartilhadas pelo Guia do cliente e pelo Hub da loja.
// Caminho das fichas em PDF, relativo às páginas (app/cliente e app/hub).
// Se você preferir reaproveitar a pasta fichas/ que já existe na raiz do repositório
// (e não subir app/fichas), troque por '../../fichas/'.
var FICHAS_BASE='../fichas/';
// WhatsApp do atendimento (somente números, com 55 e DDD).
var WHATSAPP='5594991286367';
// Hub: endereço do treinamento e do SIPATMIM (deixe vazio para ocultar o botão do SIPATMIM).
var LINK_TREINAMENTO='treinamento.html';
var LINK_SIPATMIM='';
